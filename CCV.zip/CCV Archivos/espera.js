// var urlBase = 'http://192.168.1.3/prep/panel-ccv/';
// var imgPath = 'http://192.168.1.3/prep/images/actas/';
var urlBase = 'http://192.168.110.20/';
var correo = aesDecrypt((String(localStorage.getItem("313NL14"))));

var token = localStorage.getItem("313NL15");
var myVar;
var n_tarea = 0;

espera = {
  showToastrs: false,

  tareas: function (n_tarea){
    // Get task information assigned to user in database
    var enupd = 'h0=' + token + '&tarea=' + n_tarea;
    $.ajax({
        url: urlBase + 'panel-ccv/include/loby.php',
        type: "POST",
        data: enupd,
        cache: false,
        dataType: 'json',
        success: function(response) {
          espera.loby(response);
        },
        error: function(data) {
            // alert('Error!: ' + JSON.stringify(data));
        }
    });
  },

  loby: function(data){
    // Get server response from tareas function
    var id_acta =0;
    var id_tarea =0;
    var tipo_proceso =0;
    var img = '';
      $(data).each(function(index, data) {
        id_acta = data.v2;
        tipo_proceso =data.v1;
        id_tarea =data.v3;
        img =data.v4;
      });

    localStorage.setItem("313NL9", aesEncrypt(String(id_acta)));
    localStorage.setItem("313NL10", aesEncrypt(String(tipo_proceso)));
    localStorage.setItem("313NL11", aesEncrypt(String(id_tarea)));
    localStorage.setItem("313NL12", aesEncrypt(String(img)));

    if(id_acta){
      if (tipo_proceso == 1){
        window.location.href = urlBase+"panel-ccv/captura.html";
      }
      else if (tipo_proceso == 2){
            window.location.href = urlBase+"panel-ccv/ver.html";
          }
          else if (tipo_proceso == 3 || tipo_proceso == 5 || tipo_proceso == 9){
                  window.location.href = urlBase+"panel-ccv/sup.html";
              }
    }

  },

  cerrarSesion: function() {
    // Log out function, deletes user token from database

    var token = localStorage.getItem("313NL15");

    var correo2  = sha256(correo);
    var enupd = 'h0=' + token + '&m0=' + correo2;

    // alert(enupd);
    $.ajax({
        type: "POST",
        url: urlBase + 'panel-ccv/include/cerrar.php',
        crossDomain: true,
        complete: function() {},
        data: enupd,
        dataType: 'text',
        success: function(data) { if (data == "TRUE"){
          localStorage.removeItem('313NL13');
          localStorage.removeItem('313NL15');
          window.location.href = urlBase+"panel-ccv/index.html";
        }},
        error: function(data) {
          toastrs2("Error en cerrar sesion");
        }
    });

  },

  toastrs: function(data) {
    // Function that creates notifications
    if (!showToastrs) {

      toastr.error(data);

    } else {
      toastr.error('no se puede!\'t.', 'Otro error crítico');
    }
  },

  sesionActiva: function(token){
    // Checks if user is logged in
    if(token != null){
      var correo2  = sha256(correo);
        var enupd = 'h0=' + token + '&m0=' + correo2;
        $.ajax({

            type: "POST",
            url: urlBase + 'panel-ccv/include/activa.php',
            crossDomain: true,

            complete: function() {},
            data: enupd,
            dataType: 'text',
            success: function(data) { espera.response(data); },
            error: function(data) {
                alert('Error!: ' + JSON.stringify(data));

            }
        });
    }else{
      toastrs('Error en credenciales, Inicie sesion nuevamente');
      localStorage.removeItem('313NL15');
      localStorage.removeItem('313NL13');
      setTimeout(function(){
        window.location.href =  urlBase+'panel-ccv/index.html';
      }, 200);
    }
  },

  response: function (data){
    // Get server response if user's logged in
    // if(data != "True")
    if(aesDecrypt((String(data))) != "True")
    {
      toastrs('Error en credenciales, Inicie sesion nuevamente');
      localStorage.removeItem('313NL15');
      localStorage.removeItem('313NL13');
      setTimeout(function(){
        window.location.href =  urlBase+'panel-ccv/index.html';
      }, 200);
    }
  },

  onload: function() {
    // recibimiento de json con asignacion de las tareas de los usuarios
    
      var source = new EventSource(urlBase+"core/dispatcher.php");

      source.onmessage = function(event) {
        let archivo = event.data;
        archivo = JSON.parse(archivo);
        let tarea = archivo.find(archivo => archivo.token == token);
        if(tarea){
          espera.tareas(tarea.task);
        }
      };
    
  }

}

document.addEventListener("DOMContentLoaded", function(event) {
  // Check if DOM is loaded, then beggins task
  espera.sesionActiva(localStorage.getItem("313NL15"));
  var nombre2 = aesDecrypt((String(localStorage.getItem("313NL13"))));
  document.getElementById('n_usuario').innerHTML = "<span class=\"mr-2 d-none d-lg-inline text-gray-600 small\" id=\"n_usuario\">" + nombre2 + " </span>";
});
