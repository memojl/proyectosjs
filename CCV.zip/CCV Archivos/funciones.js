var isMarch = false;
var acumularTime = 0;

//desactivar clic dercho
document.addEventListener('contextmenu', event => event.preventDefault());





// Begin timer
function start() {
  if (isMarch == false) {
    timeInicial = new Date();
    control = setInterval(cronometro, 10);
    isMarch = true;
  }
}

function cronometro() {
  timeActual = new Date();
  acumularTime = timeActual - timeInicial;
  acumularTime2 = new Date();
  acumularTime2.setTime(acumularTime);
  cc = Math.round(acumularTime2.getMilliseconds() / 10);
  ss = acumularTime2.getSeconds();
  mm = acumularTime2.getMinutes();
  hh = acumularTime2.getHours() - 18;
  if (cc < 10) {
    cc = "0" + cc;
  }
  if (ss < 10) {
    ss = "0" + ss;
  }
  if (mm < 10) {
    mm = "0" + mm;
  }
  if (hh < 10) {
    hh = "0" + hh;
  }
  pantalla.innerHTML = hh + " : " + mm + " : " + ss + " : " + cc;
}

// Stop timer
function stop() {
  if (isMarch == true) {
    clearInterval(control);
    isMarch = false;
  }
}

// Reset timer
function reset() {
    if (isMarch == true) {
      clearInterval(control);
      isMarch = false;
    }
    acumularTime = 0;
    pantalla.innerHTML = "00 : 00 : 00 : 00";
  }


  //desactivar pegado y copiado de informacion en inputs
  function copyPaste(id){
    $(document).ready(function(){
    $("#"+id).on('paste', function(e){
      e.preventDefault();
    })

    $("#"+id).on('copy', function(e){
      e.preventDefault();
    })
  })
  }

//function to rotate images
function rotate() {
    foto = new Image();
    foto.src = urlBase + 'actas/' + aesDecrypt((String(localStorage.getItem("313NL12"))));
    ancho = foto.width;
    alto = foto.height;
    rotateg = rotateg + 90;

    if (rotateg >= 360) {
      rotateg = 0;
    }
    value = -rotateg;
    console.log("grados" + value);
    if (rotateg == 90 || rotateg == 270) {
      if (ancho > alto) {
        document.getElementById('img-acta-captura').classList.add('rotatedImg2');
      } else {
        document.getElementById('img-acta-captura').classList.add('rotatedImg');
      }
    } else {
      if (ancho > alto) {
        document.getElementById('img-acta-captura').classList.remove('rotatedImg2');

      } else {
        document.getElementById('img-acta-captura').classList.remove('rotatedImg');
      }
    }
    document.getElementById('img-acta-captura').style.msTransform = "rotate(" + value + "deg)";
    document.getElementById('img-acta-captura').style.transform = "rotate(" + value + "deg)";

    document.getElementById('zoomImg').style.msTransform = "rotate(" + value + "deg)";
    document.getElementById('zoomImg').style.transform = "rotate(" + value + "deg)";

  }

  // Hides page loader
  function showPage() {
    document.getElementById("loader").style.display = "none";
    document.getElementById("loader-padre").style.display = "none";
  }


 // Log out
function cerrarSesion() {
  token = localStorage.getItem("313NL15");
  var correo2 = aesDecrypt((String(localStorage.getItem("313NL14"))));
  correo2 = sha256(correo2);
  var enupd = 'h0=' + token + '&m0=' + correo2;

  $.ajax({
    type: "POST",
    url: urlBase + 'panel-ccv/include/cerrar.php',
    crossDomain: true,
    complete: function () {},
    data: enupd,
    dataType: 'text',
    success: function (data) {
      if(data == "TRUE"){
        localStorage.removeItem('313NL15');
        localStorage.removeItem('313NL15');
        localStorage.removeItem('313NL17');
        window.location.href = urlBase + "panel-ccv/index.html";
      }
    },
    error: function (data) {
      toastrs2("Error en cerrar sesion");
    }
  });

}

var base_home = 'http://192.168.110.20/';
var timeout;
var URLactual = window.location;

var pathArray = window.location.pathname.split('/');
var file = pathArray.pop();

//comprobar si se movio el mouse en la pagina

document.onmousemove = function(){
    window.clearTimeout(timeout);
    if(file != 'index.html'){
      contadorSesion(); //aqui cargamos la funcion de inactividad
    }
}


// alert("Tiempo de reinicio: "+aesDecrypt((String(localStorage.getItem("313NL17")))));

function contadorSesion() {
  timeout = setTimeout(function () {
       $.confirm({
           title: 'Alerta de Inactividad!',
           content: 'La sesión esta a punto de expirar.',
           autoClose: 'expirar|10000',//cuanto tiempo necesitamos para cerrar la sess automaticamente
           type: '#9d0fa4',
           icon: 'fa fa-spinner fa-spin',
           buttons: {
               expirar: {
                   text: 'Cerrar Sesión',
                   btnClass: 'btn-red',
                   action: function () {
                    cerrarSesion();
                   }
               },
               permanecer: function () {
                  
               }
           }
       });
   }, parseInt(aesDecrypt((String(localStorage.getItem("313NL17")))))*1000);//
}

document.addEventListener("DOMContentLoaded", function(event) {
  contadorSesion();
});
