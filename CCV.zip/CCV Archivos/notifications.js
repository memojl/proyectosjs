// Beggins notification toastr

toastr.options = {
    "closeButton": false,
    "debug": false,
    "newestOnTop": false,
    "progressBar": true,
    "positionClass": "toast-top-full-width",
    "preventDuplicates": false,
    "onclick": null,
    "showDuration": "300",
    "hideDuration": "1000",
    "timeOut": "3000",
    "extendedTimeOut": "1000",
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
}

var showToastrs = false;

// Receives notification content
function toastrs(data) {
    if (!showToastrs) {
      toastr.error(data);
    } else {
      toastr.error('no se puede!\'t.', 'Otro error crítico');
    }
}

// Receives notification content
function toastrs2(data) {
    if (!showToastrs) {
        toastr.warning(data);
    }
}

toastr.options.onFadeIn = function() {
  showToastrs = true;
};
toastr.options.onFadeOut = function() {
  showToastrs = false;
};